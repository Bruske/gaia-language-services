  // theme sync with Claude.ai host, if present
  (function() {
    try {
      window.addEventListener('message', function(e) {
        if (e.data && e.data.type === 'theme-change' && e.data.theme) {
          document.documentElement.setAttribute('data-theme', e.data.theme);
        }
      });
    } catch (err) {}
  })();

  // add extra date rows
  document.getElementById('add-date').addEventListener('click', function() {
    var rows = document.getElementById('date-rows');
    var row = document.createElement('div');
    row.className = 'date-row';
    row.innerHTML = '<input type="date" name="data"><button type="button" aria-label="Remover esta data">×</button>';
    row.querySelector('button').addEventListener('click', function() { row.remove(); });
    rows.appendChild(row);
  });

  function buildSummary() {
    var form = document.getElementById('quote-form');
    var nome = form.nome.value.trim();
    var email = form.email.value.trim();
    var whatsapp = form.whatsapp.value.trim();
    var modalidade = form.querySelector('input[name="modalidade"]:checked').value;

    var servicos = Array.from(form.querySelectorAll('input[name="servico"]:checked')).map(function(el) { return el.value; });
    var idiomas = Array.from(form.querySelectorAll('input[name="idioma"]:checked')).map(function(el) { return el.value; });
    var detalhes = form.detalhes.value.trim();

    var datas = Array.from(form.querySelectorAll('input[name="data"]')).map(function(el) { return el.value; }).filter(Boolean);
    var inicio = form.horario_inicio.value;
    var fim = form.horario_fim.value;

    var lines = [];
    lines.push('Solicitação de orçamento — Gaia Language Services');
    lines.push('');
    lines.push('Nome: ' + (nome || '-'));
    lines.push('E-mail: ' + (email || '-'));
    lines.push('WhatsApp: ' + (whatsapp || '-'));
    lines.push('Prefere ser contatado por: ' + modalidade);
    lines.push('');
    lines.push('Tipo de serviço: ' + (servicos.length ? servicos.join('; ') : '-'));
    lines.push('Idiomas: ' + (idiomas.length ? idiomas.join('; ') : '-'));
    if (detalhes) lines.push('Contexto do evento: ' + detalhes);
    lines.push('');
    lines.push('Data(s) do evento: ' + (datas.length ? datas.join(', ') : '-'));
    lines.push('Horário: ' + (inicio || '-') + (fim ? (' às ' + fim) : ''));
    return { text: lines.join('\n'), nome: nome, email: email };
  }

  function validateRequired() {
    var form = document.getElementById('quote-form');
    var msg = document.getElementById('form-msg');
    if (!form.nome.value.trim() || !form.email.value.trim() || !form.whatsapp.value.trim()) {
      msg.textContent = 'Por favor, preencha nome, e-mail e WhatsApp antes de enviar.';
      msg.classList.add('show');
      return false;
    }
    msg.classList.remove('show');
    return true;
  }

  document.getElementById('send-email').addEventListener('click', function() {
    if (!validateRequired()) return;
    var s = buildSummary();
    var subject = encodeURIComponent('Solicitação de orçamento — ' + (s.nome || 'Gaia Language Services'));
    var body = encodeURIComponent(s.text);
    window.location.href = 'mailto:aileensb2@gmail.com?subject=' + subject + '&body=' + body;
  });

  document.getElementById('send-whatsapp').addEventListener('click', function() {
    if (!validateRequired()) return;
    var s = buildSummary();
    var text = encodeURIComponent(s.text);
    window.open('https://wa.me/5511937740570?text=' + text, '_blank');
  });
